import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class Home extends Component {
  render() {
    return (
      <div>
        <h1>Bienvenido a la página de inicio</h1>
        <Link to="/contract">Ir al contrato</Link>
      </div>
    );
  }
}

export default Home;
