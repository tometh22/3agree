import React, { Component } from 'react';

class Contract extends Component {
  state = {
    contractAddress: '',
    contractData: ''
  };

  handleInputChange = event => {
    this.setState({
      [event.target.name]: event.target.value
    });
  };

  handleSubmit = event => {
    event.preventDefault();
    // Aquí va el código para interactuar con el contrato inteligente
  };

  render() {
    return (
      <div>
        <h1>Interactuar con contrato inteligente</h1>
        <form onSubmit={this.handleSubmit}>
          <div>
            <label htmlFor="contractAddress">Dirección del contrato:</label>
            <input
              type="text"
              id="contractAddress"
              name="contractAddress"
              value={this.state.contractAddress}
              onChange={this.handleInputChange}
            />
          </div>
          <div>
            <label htmlFor="contractData">Datos del contrato:</label>
            <input
              type="text"
              id="contractData"
              name="contractData"
              value={this.state.contractData}
              onChange={this.handleInputChange}
            />
          </div>
          <button type="submit">Interactuar</button>
        </form>
      </div>
    );
  }
}

export default Contract;
