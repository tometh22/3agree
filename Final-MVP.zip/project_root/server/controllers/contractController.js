const Contract = require('../models/contract');

exports.createContract = (req, res) => {
  const { description, amount } = req.body;
  const newContract = new Contract({ description, amount });
  newContract
    .save()
    .then((contract) => {
      res.status(201).json({ message: 'Contrato creado con éxito', contract });
    })
    .catch((error) => {
      res.status(500).json({ error });
    });
};

exports.getAllContracts = (req, res) => {
  Contract.find()
    .then((contracts) => {
      res.status(200).json({ contracts });
    })
    .catch((error) => {
      res.status(500).json({ error });
    });
};

exports.getContract = (req, res) => {
  Contract.findById(req.params.contractId)
    .then((contract) => {
      res.status(200).json({ contract });
    })
    .catch((error) => {
      res.status(500).json({ error });
    });
};

exports.updateContract = (req, res) => {
  const { description, amount } = req.body;
  Contract.findByIdAndUpdate(
    req.params.contractId,
    { description, amount },
    { new: true }
  )
    .then((contract) => {
      res.status(200).json({ message: 'Contrato actualizado con éxito', contract });
    })
    .catch((error) => {
      res.status(500).json({ error });
    });
};

exports.deleteContract = (req, res) => {
  Contract.findByIdAndDelete(req.params.contractId)
    .then(() => {
      res.status(200).json({ message: 'Contrato eliminado con éxito' });
    })
    .catch((error) => {
      res.status(500).json({ error });
    });
};
