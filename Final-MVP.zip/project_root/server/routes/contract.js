const express = require("express");
const contractController = require("../controllers/contractController");

const router = express.Router();

// Create new contract
router.post("/", contractController.create);

// Get contract by id
router.get("/:id", contractController.getById);

// Update contract by id
router.put("/:id", contractController.update);

// Delete contract by id
router.delete("/:id", contractController.delete);

module.exports = router;
